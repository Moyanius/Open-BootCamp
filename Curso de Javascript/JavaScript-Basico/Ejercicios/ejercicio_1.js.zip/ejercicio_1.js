const datos = ["Jose", 38, true];

const datos2 = new Date (2022, 0, 10)

const libro = {
    titulo: "Zara",
    autor: "Ni idea",
    fecha: 15/02/1989,
    url: "http://google.es"
}

console.log(datos, datos2, libro)